import json
import os
import tkinter as tk
from tkinter import scrolledtext, messagebox

def load_responses():
    responses = {}
    if os.path.exists('responses.json') and os.stat('responses.json').st_size != 0:
        with open('responses.json', 'r') as file:
            responses = json.load(file)
    return responses

def save_responses(responses):
    with open('responses.json', 'w') as file:
        json.dump(responses, file)

def send_message(event=None):
    message = user_entry.get().strip()
    if message:
        chat_log.config(state=tk.NORMAL)
        chat_log.insert(tk.END, "You: " + message + "\n")
        chat_log.config(state=tk.DISABLED)
        user_entry.delete(0, tk.END)
        responses = load_responses()

        if message.lower() in ["goodbye", "cya", "bye", "close", "chow", "exit", "fuck off", "toodles", "off", "shut down"]:
            chat_log.config(state=tk.NORMAL)
            chat_log.insert(tk.END, "Chatbot: Goodbye!\n")
            chat_log.config(state=tk.DISABLED)
            save_responses(responses)
            root.after(0, count_down, 3)  # Start the countdown immediately on exit
            return
        else:
            if message.lower() in responses:
                response = responses[message.lower()]
                chat_log.config(state=tk.NORMAL)
                chat_log.insert(tk.END, "Chatbot: " + response + "\n")
                chat_log.config(state=tk.DISABLED)
            else:
                new_response = input("Chatbot: I'm not sure what to say. What should I say to that? ")
                responses[message.lower()] = new_response
                chat_log.config(state=tk.NORMAL)
                chat_log.insert(tk.END, "Chatbot: " + new_response + "\n")
                chat_log.config(state=tk.DISABLED)
                save_responses(responses)

def count_down(timer):
    if timer > 0:
        chat_log.config(state=tk.NORMAL)
        chat_log.insert(tk.END, f"Blazebot: Self Destructing in {timer} seconds...\n")
        chat_log.config(state=tk.DISABLED)
        root.after(1000, count_down, timer - 1)
    else:
        root.destroy()

def display_opening_messages():
    chat_log.config(state=tk.NORMAL)
    chat_log.insert(tk.END, "Blazebot: Great work back there!\n")
    chat_log.config(state=tk.DISABLED)

    root.after(2000, lambda: chat_log.config(state=tk.NORMAL))
    root.after(2000, lambda: chat_log.insert(tk.END, "Blazebot: You'll have to go back to the album though because I'm gonna quiz you.\n"))
    root.after(2000, lambda: chat_log.config(state=tk.DISABLED))

    root.after(4000, lambda: chat_log.config(state=tk.NORMAL))
    root.after(4000, lambda: chat_log.insert(tk.END, "Blazebot: #\n"))
    root.after(4000, lambda: chat_log.config(state=tk.DISABLED))

def on_exit():
    if messagebox.askokcancel("Quit", "Do you want to quit the chat?"):
        root.after(0, count_down, 3)

# Create the root window
root = tk.Tk()
root.title("Blazebot")

# Calculate the screen width and height
screen_width = root.winfo_screenwidth()
screen_height = root.winfo_screenheight()

# Calculate the position for the window to be centered
window_width = 800  # Adjust as needed
window_height = 400  # Adjust as needed
x_coordinate = (screen_width - window_width) // 2
y_coordinate = (screen_height - window_height) // 2

# Set the window size and position
root.geometry(f"{window_width}x{window_height}+{x_coordinate}+{y_coordinate}")

root.columnconfigure(0, weight=1)
root.rowconfigure(0, weight=1)

chat_log = scrolledtext.ScrolledText(root, width=75, height=25)
chat_log.grid(row=0, column=0, padx=10, pady=10, sticky="nsew")
chat_log.config(state=tk.DISABLED)

user_entry = tk.Entry(root, width=40)
user_entry.grid(row=1, column=0, padx=10, pady=10, sticky="ew")
user_entry.bind("<Return>", send_message)

root.protocol("WM_DELETE_WINDOW", on_exit)

root.after(250, display_opening_messages)

root.mainloop()
